package com.example.dell.flightinventorymanagement.userdetail;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.dell.flightinventorymanagement.Parts;
import com.example.dell.flightinventorymanagement.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class UserDetails extends AppCompatActivity {
    Toolbar toolbar;
    FirebaseDatabase database;
    DatabaseReference myRef;
    ArrayList<Parts> arrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);
        toolbar = (Toolbar) findViewById(R.id.toolbar5);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Part Information");
        database = FirebaseDatabase.getInstance();
        arrayList = new ArrayList<>();
        myRef = database.getReference("parts");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                //clearing the previous artist list
                arrayList.clear();

                //iterating through all the nodes
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    //getting artist
                    Parts artist = postSnapshot.getValue(Parts.class);
                    //Toast.makeText(UserDetails.this, artist.getSerial(), Toast.LENGTH_SHORT).show();
                    //adding artist to the list
                    arrayList.add(artist);
                }

                //myRef.setValue("Hello, World!");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

            @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==android.R.id.home)
        {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
